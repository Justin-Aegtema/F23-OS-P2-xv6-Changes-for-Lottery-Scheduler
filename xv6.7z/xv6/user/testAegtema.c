/*The following file is entirely added by Justin Aegtema jtb200002
 * I use this code to test my other code additions in the user directory */
//#include "../kernel/rand_num_gen.h"
#include "types.h"
#include "stat.h"
#include "user.h"

int main(void) {

/* *** this code tests the functionality of the random number generator
 *  * * */
        
	
	// *** this is basic code to test a basic version of settickets which merely returns 4444
	// *** all this does is ensure that settickets is a properly created system call
  	//int ret = settickets(1);
    	//if (ret == 4444) {
        //	printf(1, "Test passed: settickets returned %d\n", ret);
	//} else {
	//      	printf(1, "Test failed: settickets returned %d\n", ret);
	//}
	

	// *** this tests settickets; it tests
	// *** whether settickets actually sets the tickets properly
	// *** (while testing this, the code to print the values was inside settickets itself
	/*
	printf(1, "Expected print outs: 5, 10, 15, 100\n");
	settickets(5);
	settickets(10);
	settickets(15);
	settickets(100);
	exit();
	*/

	return 0;
}
