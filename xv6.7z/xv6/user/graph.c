/*this entire function was added by Justin Aegtema jtb200002
 * This code was added to fulfil the graph requirements for the project
 * This code creates 4 processes.
 * The first three have a 3:2:1 ticket ratio with 3000, 2000, and 1000 tickets.
 * The fourth one counts the total number of ticks across all processes, printing
 * The total ticks for each of the first three processees after a certain threshold of 
 * total ticks has been reached (presently the threshold is set to 300 total ticks
 * */

#include "pstat.h"
#include "param.h"
#include "types.h"
#include "user.h"
#include "fs.h"


//spin is simply a function that takes up a process's time
//for the purposes of measuring how much time/attention it gets from the scheduler
void spin()
{
    int i = 0;
    int j = 0;
    int k = 0;
    for(i = 0; i < 100000; ++i){
      for(j = 0; j < 30000; ++j){
        k = j % 10;
        k = k + 1;
      }
    }
}

int main(){

//the 1st process is the parent process, which gets 3*tickets= 3000 tickets
  int pid_3;
  pid_3 = getpid();
  int tickets_set = 1000;
  settickets(3*tickets_set);

//2nd process gets 2*tickets = 2000 tickets, then spins
  int pid_2;
  pid_2 = fork(); 
  if(pid_2 == 0) {
    settickets(2*tickets_set);
    spin();
    exit();
  }

//3rd process gets 1*tickets = 1000 tickets, then spins
  int pid_1;
  pid_1 = fork();
  if(pid_1 == 0) {
    settickets(tickets_set);
    spin();
    exit();
  }

//4th process is created to measure total ticks
//and ultimately print total ticks for each of the 1st three processes
//after a certain threshold of total ticks across all processes is met
//presently, the threshold is 300 ticks total
  int pid_X;
  pid_X = fork();

  if(pid_X == 0) {
    settickets(3*tickets_set);
    struct pstat st;
    int sum_ticks = 0;
    while(sum_ticks < 300) {//stays here until total ticks across all processes is at least 300
      getpinfo(&st);
      int i;
      sum_ticks = 0;
      for(i=0; i < NPROC; i++){
        sum_ticks = sum_ticks + st.ticks[i];
      }
    }

    getpinfo(&st);// populate st w the process statistics

    //these blocks of code print off the process statistics for each of the 3 processes of interest
    //this allows for their actual number of ticks to be compared to their ticket ratio
    int i;
    for(i = 0; i < NPROC; i++) {
      if(st.pid[i] == pid_3){
        printf(1, "pid_3: %d tickets: %d ticks: %d\n", st.pid[i], st.tickets[i], st.ticks[i]);
      }
    }

    for(i = 0; i < NPROC; i++) {
      if(st.pid[i] == pid_2){
        printf(1, "pid_2: %d tickets: %d ticks: %d\n", st.pid[i], st.tickets[i], st.ticks[i]);
      }
    }

    for(i = 0; i < NPROC; i++) {
      if(st.pid[i] == pid_1){
        printf(1, "pid_1: %d tickets: %d ticks: %d\n", st.pid[i], st.tickets[i], st.ticks[i]);
      }
    }

  }

  // remember, the original, parent process still has to be set to spin, so this is where that happens
  spin();
  // parent process also waits for its children to end
  wait();
  wait();
  wait();
  exit();
}
