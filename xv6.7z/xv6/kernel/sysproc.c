#include "types.h"
#include "x86.h"
#include "defs.h"
#include "param.h"
#include "mmu.h"
#include "proc.h"
#include "sysfunc.h"
/* code added to include pstat.h by Justin Aegtema jtb200002 */
#include "pstat.h"
/* End of added code */

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return proc->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = proc->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;
  
  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(proc->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since boot.
int
sys_uptime(void)
{
  uint xticks;
  
  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

//* The following code is added by Justin Aegtema jtb200002
//** this code defines both sys_settickets and sys_getpinfo according to project specifications
//** in the case of sys_settickets, this allows the user facing settickets(int)'s int value to set the ticket_count of the current process p
//*/
int
sys_settickets(void)
{
	int ticket_count;
	if(argint(0, &ticket_count) < 0){ //assign user's input value to ticket_count, check if argint is successful
		return -1;
	}
	if(ticket_count < 1){ //check ticket_count is at least 1
		return -1;
	}
	//code here to update the number of tickets
	//struct proc *p = myproc(); // retrieve current process p
	proc->ticket_count = ticket_count; // set p's ticket_count to ticket_count from settickets(int) user function
	//to find the appropriate entry to update in tickets[],
	//first search for the matching index in pid_pstat[]
	int index_match = -1;
	int i_curr_proc;
	for(i_curr_proc = 0; i_curr_proc < NPROC; i_curr_proc++) {
		if(pid_pstat[i_curr_proc] == proc->pid) {//break from this loop once you find the right index
			index_match = i_curr_proc;
			break;
		}
	}
	tickets[index_match] = proc->ticket_count; //update number of tickets in tickets[] for pstat

	return 0;
}

int
sys_getpinfo(void)//set values of my_pstat to the corresponding global variables 
//so that user has access to tickets, ticks, and other process stats
{
	struct pstat *my_pstat;
	if(argptr(0, (void*)&my_pstat, sizeof(*my_pstat)) < 0) {//retrieve and check my_pstat from user
		return -1; //error if the pointer is invalid
	}

  	if (my_pstat == NULL) {
      		return -1; // Return -1 if the pointer is NULL
        }

	int i;
	for (i = 0; i < NPROC; ++i) {//this for loop updates the entire my_stat that is returned to the user
	//it does this using global arrays, which themselves are appropriately updated throughout the 
	//regular functioning of the program
		my_pstat->inuse[i] = inuse[i];
		my_pstat->tickets[i] = tickets[i];
		my_pstat->pid[i] = pid_pstat[i];
		my_pstat->ticks[i] = ticks_pstat[i];
	}
	return 0;
}
// /*End of code added*/
